﻿using Microsoft.EntityFrameworkCore;

namespace Kanini_Assessment.Models
{
    public class MainDbContext : DbContext
    {
        public MainDbContext(DbContextOptions<MainDbContext> options) : base(options) 
        {

        }

        public DbSet<Hotel_Details> hotels { get; set; }
        public DbSet<Room_Details> rooms { get; set; }
        public DbSet<User_Details> users { get; set; }
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
        }
    }
}
