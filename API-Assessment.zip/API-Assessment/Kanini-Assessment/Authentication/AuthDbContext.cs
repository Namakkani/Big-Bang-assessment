﻿using Microsoft.EntityFrameworkCore;

namespace Kanini_Assessment.Authentication
{
    public class AuthDbContext :DbContext
    {
        public AuthDbContext(DbContextOptions dbContextOptions) : base(dbContextOptions) { }
        public DbSet<User> user { get; set; }
    }
}
