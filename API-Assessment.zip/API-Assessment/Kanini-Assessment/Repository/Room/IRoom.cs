﻿using Microsoft.AspNetCore.Mvc;
using Kanini_Assessment.Models;
using System.Threading.Tasks;

namespace Kanini_Assessment.Repository.Room
{
    public interface IRoom
    {
        Task<Room_Details> PostRoom(Room_Details room);
        Task<IEnumerable<Room_Details>> GetRooms();
        Task<Room_Details> GetRoom(int id);
        Task<Room_Details> PutRoom(int id, Room_Details room);
        Task<string> DeleteRoom(int id);
    }
}
