﻿using Kanini_Assessment.Models;
using Kanini_Assessment.Repository.Room;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;

namespace Kanini_Assessment.Repository.Room
{
        public class RoomServices : IRoom
        {

            private readonly MainDbContext _context;

            public RoomServices(MainDbContext context)
            {
                _context = context;
            }

            //---------------------------------------------
            //posting hotels 
            public async Task<Room_Details> PostRoom(Room_Details room)
            {
                var itm = await _context.rooms.AddAsync(room);
                if (itm == null)
                {
                    throw new Exception("error");
                }
                _context.SaveChanges();
                return room;
            }

        //----------------------------------------------
        //getting hotel details 
        public async Task<IEnumerable<Room_Details>> GetRooms()
        {
            var ht = await _context.rooms.ToListAsync();
            if (ht == null)
            {
                throw new Exception("error");
            }
            return ht;
        }

        //-------------------------------------------------------------
        //getting specific hotel by calling its id
        public async Task<Room_Details> GetRoom(int id)
        {
            Room_Details dp = await _context.rooms.FirstOrDefaultAsync(x => x.RoomId == id);
            if (dp == null)
            {
                throw new Exception("Invalid hotel id");
            }
            return dp;
        }

        //--------------------------------------------------------------------
        public async Task<Room_Details> PutRoom(int id, Room_Details room)
        {
            Room_Details dp = await _context.rooms.FirstOrDefaultAsync(x => x.RoomId == id);
            dp.RoomType = room.RoomType;
            if (dp.RoomType == null)
            {
                throw new Exception("Invalid User");
            }
            return dp;
        }

        //----------------------------------------------------------------------
        public async Task<string> DeleteRoom(int id)
        {
            Room_Details dp = await _context.rooms.FirstOrDefaultAsync(x => x.RoomId == id);
            if (dp == null)
            {
                throw new Exception("Invalid Hotel");
            }
            _context.Remove(dp);
            _context.SaveChanges();
            return "deleted Successfully";
        }
    }
}
    

