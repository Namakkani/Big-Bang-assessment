﻿using Kanini_Assessment.Models;
using Kanini_Assessment.Repository.HotelsUser;
using Microsoft.CodeAnalysis.CSharp.Syntax;
using Microsoft.EntityFrameworkCore;
using Newtonsoft.Json.Linq;

//counts performances
namespace Kanini_Assessment.Repository.HotelsUser
{
    public class UserGetHotelServices : IHotelUsere
    {
        private readonly MainDbContext context;

        public UserGetHotelServices(MainDbContext hotelContext)
        {
            this.context = hotelContext;
        }

        //getting rooms available hotels
        public async Task<IEnumerable<BufferTable>> GetAvailableHotels()
        {
            var ans = (from h in context.hotels
                       join r in context.rooms on h.HotelId equals r.HotelId
                       where r.RoomStatus == "Available"
                       select new BufferTable()
                       {
                           HotelName = h.HotelName,
                           Phone = h.Phone,
                           TotalRoomCount = context.rooms.Count(s => s.RoomStatus == "Available")
                       }).ToListAsync();
            if (ans == null)
            {
                throw new Exception("hotel does not have available rooms");
            }
            return await ans;
        }


        //getting rooms available hotels
        public async Task<IEnumerable<BufferTable>> GetAvailablePlaceHotels()
        {
            var place = (from h in context.hotels
                         join r in context.rooms on h.HotelId equals r.HotelId
                         where h.Place == "chennai"
                         select new BufferTable()
                         {
                             Place = h.Place,
                             HotelName = h.HotelName,
                             Phone = h.Phone,
                             TotalRoomCount = context.rooms.Count(s => s.RoomStatus == "Available")
                         }).ToListAsync();
            if (place == null)
            {
                throw new Exception("Hotel does not in this place for booking");
            }
            return await place;
        }

        public async Task<IEnumerable<BufferTable>> GetAvailablePriceHotels()
        {
            var price = (from h in context.hotels
                         join r in context.rooms on h.HotelId equals r.HotelId
                         where r.RoomPricePerNight == "200"
                         select new BufferTable()
                         {
                             Place = h.Place,
                             HotelName = h.HotelName,
                             Phone = h.Phone,
                             TotalRoomCount = context.rooms.Count(s => s.RoomStatus == "Available"),
                             RoomPricePerNight = r.RoomPricePerNight,
                             RoomType = r.RoomType,
                         }).ToListAsync();
            if(price == null) 
            {
                throw new Exception("Price range hotel not available");
            }
            return await price;
        }

    }
}

