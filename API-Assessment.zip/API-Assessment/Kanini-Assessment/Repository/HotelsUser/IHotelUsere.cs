﻿using Kanini_Assessment.Models;

namespace Kanini_Assessment.Repository.HotelsUser
{
    public interface IHotelUsere
    {
        public Task<IEnumerable<BufferTable>> GetAvailableHotels();

        public Task<IEnumerable<BufferTable>> GetAvailablePlaceHotels();

        public Task<IEnumerable<BufferTable>> GetAvailablePriceHotels();
    }
}
