﻿using Kanini_Assessment.Models;
using Kanini_Assessment.Repository.HotelsUser;

namespace Kanini_Assessment.Repository.RoomUser
{
    public interface IRoomUser
    {
        public Task<IEnumerable<RoomBufferTable>> GetAvailableRooms();

        public Task<IEnumerable<RoomBufferTable>> GetAffordablePriceRooms();

        public Task<IEnumerable<RoomBufferTable>> RoomBookingStatus();
    }
}
