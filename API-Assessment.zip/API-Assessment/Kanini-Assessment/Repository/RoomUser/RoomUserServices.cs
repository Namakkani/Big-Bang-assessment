﻿using Kanini_Assessment.Models;
using Kanini_Assessment.Repository.HotelsUser;
using Microsoft.EntityFrameworkCore;

namespace Kanini_Assessment.Repository.RoomUser
{
    public class RoomUserServices : IRoomUser
    {
        private readonly MainDbContext context;

        public RoomUserServices(MainDbContext context)
        {
            this.context = context;
        }

        public async Task<IEnumerable<RoomBufferTable>> GetAvailableRooms()
        {
            var AvailRoom = (from h in context.hotels
                         join r in context.rooms on h.HotelId equals r.HotelId
                         where h.HotelName == "Retro"
                         select new RoomBufferTable()
                         {
                             Place = h.Place,
                             HotelName = h.HotelName,
                             Phone = h.Phone,
                             AvailableRoomCount = context.rooms.Count(s => s.RoomStatus == "Available"),
                             RoomPricePerNight = r.RoomPricePerNight,
                             RoomType = r.RoomType,
                         }).ToListAsync();
            if (AvailRoom == null)
            {
                throw new Exception("Specified Hotel Available room count");
            }
            return await AvailRoom;
        }

        public async Task<IEnumerable<RoomBufferTable>> GetAffordablePriceRooms()
        {
            var AvailRoom = (from h in context.hotels
                             join r in context.rooms on h.HotelId equals r.HotelId
                             where h.HotelName == "Retro" && r.RoomPricePerNight == "200"
                             select new RoomBufferTable()
                             {
                                 Place = h.Place,
                                 HotelName = h.HotelName,
                                 Phone = h.Phone,
                                 AvailableRoomCount = context.rooms.Count(s => s.RoomStatus == "Available"),
                                 RoomPricePerNight = r.RoomPricePerNight,
                                 RoomType = r.RoomType,
                             }).ToListAsync();
            if (AvailRoom == null)
            {
                throw new Exception("This range price room not available");
            }
            return await AvailRoom;
        }

        public async Task<IEnumerable<RoomBufferTable>> RoomBookingStatus()
        {
            var AvailRoom = (from h in context.hotels
                             join r in context.rooms on h.HotelId equals r.HotelId
                             where h.HotelName == "Retro" && r.RoomStatus == "Booked"
                             select new RoomBufferTable()
                             {
                                 Place = h.Place,
                                 HotelName = h.HotelName,
                                 Phone = h.Phone,
                                 AvailableRoomCount = context.rooms.Count(s => s.RoomStatus == "Available"),
                                 RoomPricePerNight = r.RoomPricePerNight,
                                 RoomType = r.RoomType,
                             }).ToListAsync();
            if(AvailRoom == null)
            {
                throw new Exception("Room not Booked");
            }
            return await AvailRoom;
        }
    }
}
