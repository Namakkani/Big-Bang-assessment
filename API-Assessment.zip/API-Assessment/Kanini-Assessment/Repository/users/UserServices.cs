﻿using Kanini_Assessment.Models;
using Kanini_Assessment.Repository.Room;
using Kanini_Assessment.Repository.users;

namespace Kanini_Assessment.Repository.users
{
    public class UserServices : IUser
    {
        private readonly MainDbContext _context;

        public UserServices(MainDbContext context)
        {
            _context = context;
        }

        public async Task<User_Details> PostUser(User_Details users)
        {
            var itm = await _context.users.AddAsync(users);
            if (itm == null)
            {
                throw new Exception("error");
            }
            _context.SaveChanges();
            return users;
        }
    }
}
