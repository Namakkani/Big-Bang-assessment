﻿using Microsoft.AspNetCore.Mvc;
using Kanini_Assessment.Models;
using System.Threading.Tasks;

namespace Kanini_Assessment.Repository
{
    public interface IHotel
    {
        Task<Hotel_Details> PostHotel(Hotel_Details hotel);
        Task<IEnumerable<Hotel_Details>> GetHotels();
        Task<Hotel_Details> GetHotel(int id);
        Task<Hotel_Details> PutHotel(int id, Hotel_Details hotel);
        Task<string> DeleteHotel(int id);
    }
}
