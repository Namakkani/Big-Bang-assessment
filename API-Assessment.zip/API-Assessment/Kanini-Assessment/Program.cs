using Kanini_Assessment.Authentication;
using Kanini_Assessment.Models;
using Kanini_Assessment.Repository;
using Kanini_Assessment.Repository.HotelsUser;
using Kanini_Assessment.Repository.Room;
using Kanini_Assessment.Repository.RoomUser;
using Kanini_Assessment.Repository.users;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.EntityFrameworkCore;
using Microsoft.IdentityModel.Tokens;
using System.Text;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

builder.Services.AddDbContext<MainDbContext>(optionsAction: options => options.UseSqlServer(builder.Configuration.GetConnectionString("connection")));
builder.Services.AddDbContext<AuthDbContext>(optionsAction: options => options.UseSqlServer(builder.Configuration.GetConnectionString("Auth")));

builder.Services.AddScoped<IHotel, HotelServices>();
builder.Services.AddScoped<IRoom, RoomServices>();
builder.Services.AddScoped<IUser,UserServices>();
builder.Services.AddScoped<IHotelUsere, UserGetHotelServices>();
builder.Services.AddScoped<IRoomUser, RoomUserServices>();


//---------------------------------------------------------------------
//jwt builder
builder.Services.AddControllers().AddNewtonsoftJson(options =>
{
    options.SerializerSettings.ReferenceLoopHandling =
    Newtonsoft.Json.ReferenceLoopHandling.Ignore;
});

// Adding Authentication
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
})

// Adding Jwt Bearer
.AddJwtBearer(options =>
{
    options.SaveToken = true;
    options.RequireHttpsMetadata = false;
    options.TokenValidationParameters = new TokenValidationParameters()
    {
        ValidateIssuer = true,
        ValidateAudience = true,
        ValidAudience = builder.Configuration["JWT:Audience"],
        ValidIssuer = builder.Configuration["JWT:Issuer"],
        IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["JWT:Key"]))
    };
});

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
